import React from 'react';
import autoBind from 'react-autobind';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { AgGridReact } from 'ag-grid-react';
import 'ag-grid/dist/styles/ag-grid.css';
import 'ag-grid/dist/styles/ag-theme-balham.css';

import {changeSelectedItem} from '../state/actions/GridActions';

class TestComponent extends React.Component {

    constructor(props) {
        super(props);
        autoBind(this);
    }

    onRowClicked = (event) => {
        this.props.changeSelectedItem(event.data);
        console.log(this.props);
    };

    render() {
        const gridData = {
            columnDefs: [
                {headerName: 'Make', field: 'make'},
                {headerName: 'Model', field: 'model'},
                {headerName: 'Price', field: 'price'},
                {headerName: 'Date And Time', field: 'date'}
            ],
            rowData: [
                {make: 'Toyota', model: 'Celica', price: 35000, date: '04.05.2017 13:47'},
                {make: 'Ford', model: 'Mondeo', price: 32000, date: '19.04.2018 13:47'},
                {make: 'Porsche', model: 'Boxter', price: 72000, date: '30.07.2018 13:47'}
            ]
        };

        return(
            <div
                className="ag-theme-balham"
                style={{
                    height: '500px',
                    width: '800px' }}
            >
                <AgGridReact
                    rowSelection='single'
                    onRowClicked={this.onRowClicked}
                    columnDefs={gridData.columnDefs}
                    enableFilter={'true'}
                    rowData={gridData.rowData}>
                </AgGridReact>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
  console.log(state)
    return {
        selectedRow: state.gridData
    };
};

export const mapDispatchToProps = (dispatch) => {
    return bindActionCreators({
        changeSelectedItem
    }, dispatch);
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(TestComponent);
