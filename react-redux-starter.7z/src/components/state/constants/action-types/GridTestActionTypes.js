const GridActionTypes = {
    CHANGE_SELECTED_ITEM: 'CHANGE_SELECTED_ITEM'
};

export {
    GridActionTypes
};
